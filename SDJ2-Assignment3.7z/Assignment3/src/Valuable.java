public interface Valuable {

    public String getName();
    public int getValue();
    public String toString();
}
